<template>
  <main>
    <Logo/>

    <div class="code-row">
      <div class="code-block">
        <div class="label">
          <label class="label__title" for="svg-code">Insert SVG</label>
          <a href="#">Minify</a>
        </div>

        <textarea class="code" v-model="code" spellcheck="false"></textarea>

        <highlightjs
          contenteditable="plaintext-only"
          language='xml'
          :code="code"
          @focusout="update"
          @paste="update"

          v-model="code"

          id="svg-code"
          spellcheck="false" />
      </div>

      <div class="svg-preview">
        <div class="label">
          <label for="#">Preview</label>
        </div>
        <IconPreview :svg="code"/>
      </div>

      <div class="svg-options">
        <div class="label">
          <label for="#">SVG Options</label>
        </div>

        <div class="svg-options-row">
          <div class="svg-options-item">
            <div class="label">
              <label for="#">Width</label>

              <div>
                <input type="checkbox" id="aspectRatio"/>
                <label for="aspectRatio">Aspect Ratio</label>
              </div>
            </div>

            <input type="number" placeholder="Width (px)" class="input"/>

          </div>
          <div class="svg-options-item">
            <div class="label">
              <label for="#">Height</label>
            </div>

            <input type="number" placeholder="Height (px)" class="input"/>

          </div>
          <div class="svg-options-item">
            <div class="label">
              <label for="#">SVG Color</label>
              <a href="#">to currentColor</a>
            </div>

            <div class="svg-options-item__color">
              <input type="color"/>
              <input type="text" class="input" placeholder="#000000"/>

            </div>
          </div>
          <div class="svg-options-item">
            <div class="label">
              <label for="#">Download</label>
            </div>

            <select class="input">
              <option value="1">SVG</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <h2>URL-Encoding</h2>

    <div class="result-row">
      <div class="result-item">
        <h5 class="result-item__title">URL-Encoded</h5>
        <p class="result-item__description">Spaces excluded.</p>

        <Codemirror
          v-model:value="code"
          :options="cmOptions"
          border
          placeholder="test placeholder"
          :height="200"
        />

<!--        <highlightjs-->
<!--          language="svg"-->
<!--          :code="code1"-->
<!--          spellcheck="false" />-->
      </div>

      <div class="result-item">
        <h5 class="result-item__title">URL-Encoded CSS</h5>
        <p class="result-item__description">background-image:url()</p>

        <highlightjs
          :code="code2"
          spellcheck="false" />
      </div>

      <div class="result-item">
        <h5 class="result-item__title">URL-Encoded &lt;img&gt;</h5>
        <p class="result-item__description">&lt;img src=""&gt;</p>

        <highlightjs
          :code="code3"
          spellcheck="false" />
      </div>

      <div class="result-item">
        <h5 class="result-item__title">URL-Encoded</h5>
        <p class="result-item__description">Spaces excluded.</p>

        <highlightjs
          :code="code4"
          spellcheck="false" />
      </div>
    </div>
  </main>
</template>

<script setup>

import { ref } from 'vue';

import Codemirror from "codemirror-editor-vue3";

import "codemirror/addon/display/placeholder.js";
import "codemirror/mode/javascript/javascript.js";
import "codemirror/addon/display/placeholder.js";
import "codemirror/theme/dracula.css";

const cmOptions = ref({
  mode: "text/javascript", // Language mode
  theme: "dracula", // Theme
  lineWrapping: true
});

import Logo from "@/components/Logo.vue";
import IconPreview from "@/components/IconPreview.vue";

const code = ref(`<svg viewBox="0 0 24 24"><path fill="currentColor" d="M10.05 16.94V12.94H18.97L19 10.93H10.05V6.94L5.05 11.94Z"/></svg>`);

const previewSVG = ref(`<svg viewBox="0 0 24 24"><path fill="currentColor" d="M10.05 16.94V12.94H18.97L19 10.93H10.05V6.94L5.05 11.94Z"/></svg>`);

const code1 = ref(`%3Csvg viewBox="0 0 24 24"%3E%3Cpath fill="currentColor" d="M10.05 16.94V12.94H18.97L19 10.93H10.05V6.94L5.05 11.94Z"/%3E%3C/svg%3E`);
const code2 = ref(`background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24'%3E%3Cpath fill='currentColor' d='M10.05 16.94V12.94H18.97L19 10.93H10.05V6.94L5.05 11.94Z'/%3E%3C/svg%3E");`);
const code3 = ref(`<img src="data:image/svg+xml,%3Csvg viewBox='0 0 24 24'%3E%3Cpath fill='currentColor' d='M10.05 16.94V12.94H18.97L19 10.93H10.05V6.94L5.05 11.94Z'/%3E%3C/svg%3E">`);
const code4 = ref(`<svg viewBox="0 0 24 24"><path fill="currentColor" d="M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z"/></svg>`);
const update = (e) => {
  console.log(e.target.innerText);
  code.value = e.target.innerText;
}
const updatePreview = (e) => {
  console.log(e.target.innerText);
  previewSVG.value = e.target.innerText;
}

</script>