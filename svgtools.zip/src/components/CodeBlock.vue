<template>

</template>

<script setup>
defineProps<{
  modelValue: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

function inputChanged(event: any) {
  emit('update:modelValue', event.target.textContent)
}
</script>