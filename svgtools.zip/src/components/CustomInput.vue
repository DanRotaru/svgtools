<template>
  <input
    :type="type"
    :value="modelValue"
    :placeholder="placeholder"
    :disabled="disabled"
    @input="onInput"
  />
</template>

<script setup lang="ts">
import { PropType, defineEmits } from 'vue';

// Props
const props = defineProps({
  type: {
    type: String as PropType<'text' | 'number' | 'color'>,
    default: 'text',
  },
  modelValue: {
    type: [String, Number] as PropType<string | number>,
    default: '',
  },
  placeholder: {
    type: String,
    default: '',
  },
  disabled: {
    type: Boolean,
    default: false,
  }
});

// Emit event
const emit = defineEmits(['update:modelValue']);

// Input handler
const onInput = (event: Event) => {
  const target = event.target as HTMLInputElement;
  emit('update:modelValue', target.value);
};
</script>
