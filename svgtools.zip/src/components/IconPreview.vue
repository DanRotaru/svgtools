<template>
  <div class="icon-preview" v-html="svg"></div>
</template>

<script setup>
const props = defineProps(['svg']);
</script>

<style lang="scss">
.icon-preview {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  width: 200px;
  height: 165px;
  //height: 100%;
  border-radius: 6px;
  border: 1px solid rgb(55 65 81 / 50%);

  &:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    opacity: .8;
    background: url("data:image/svg+xml;charset=utf-8,%3Csvg width='8' height='8' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23374151' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E");
  }

  svg {
    max-height: 90%;
    min-width: 16px;
    min-height: 16px;
    width: 96px;
    height: 96px;
  }
}
</style>