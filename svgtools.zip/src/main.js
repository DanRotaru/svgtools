import './assets/fonts/index.scss'
import './assets/app.scss'

import 'highlight.js/styles/atom-one-dark.css'
import hljs from 'highlight.js/lib/core';
import javascript from 'highlight.js/lib/languages/javascript';
import xml from 'highlight.js/lib/languages/xml';
import hljsVuePlugin from "@highlightjs/vue-plugin";

import { InstallCodeMirror } from "codemirror-editor-vue3";


hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('xml', xml);

import { createApp } from 'vue'
import App from './App.vue'

createApp(App)
  .use(hljsVuePlugin)
  .use(InstallCodeMirror)
  .mount('#app')
